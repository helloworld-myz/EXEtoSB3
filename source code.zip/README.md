# EXEtoSB3
可以把EXE转换为SB3文件的工具。主要重写了原作者的GUI界面，并添加了一些新的功能。其余功能与原作者保持一致。

# 感谢与参考  
本项目基于 [EXEtoSb3]](https://github.com/ZYF728/EXEtoSb3) 开发，感谢原作者的贡献！  
原项目采用 [Apache] 协议，本项目沿用相同协议。